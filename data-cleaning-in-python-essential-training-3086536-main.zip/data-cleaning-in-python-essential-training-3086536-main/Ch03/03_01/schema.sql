CREATE TABLE ships (
    name TEXT,
    lat FLOAT,
    lng FLOAT
);