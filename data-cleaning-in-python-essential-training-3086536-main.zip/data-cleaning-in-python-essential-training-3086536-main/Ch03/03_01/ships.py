# %%
import pandas as pd


df = pd.read_csv('ships.csv')
df
# %%
df.dtypes
